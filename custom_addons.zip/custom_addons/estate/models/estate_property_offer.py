from odoo import models, fields, api
from odoo.exceptions import UserError, ValidationError


class EstatePropertyOffer(models.Model):
    _name = 'estate.property.offer'
    _description = 'Property Offer'
    _order = "price desc"
    price = fields.Float()
    status = fields.Selection(
        [
            ('accepted', 'Accepted'),
            ('refused', 'Refused'),
        ],
        copy=False,
    )
    partner_id = fields.Many2one(
        'res.partner',
        required=True,
    )
    property_id = fields.Many2one(
        'estate.property',
        required=True,
        ondelete='cascade',
    )
    property_type_id = fields.Many2one(
        "estate.property.type",
        related="property_id.property_type_id",
        store=True
    )

    def action_accept(self):
        for offer in self:
            if offer.property_id.offer_ids.filtered(
                    lambda o: o.status == "accepted"
            ):
                raise UserError("Only one offer can be accepted!")

            offer.status = "accepted"
            offer.property_id.buyer_id = offer.partner_id
            offer.property_id.selling_price = offer.price

        return True

    def action_refuse(self):
        for offer in self:
            offer.status = "refused"
        return True

    _sql_constraints = [
        (
            'check_offer_price_positive',
            'check(price > 0)',
            'Offer price must be positive.'
        ),
    ]
    @api.model
    def create(self, vals):
        property_rec = self.env['estate.property'].browse(vals.get('offer.property_id.id'))
        existing_offers = property_rec.offer_ids.mapped('price')
        if existing_offers and vals.get('price') < max(existing_offers):
            raise ValidationError("You cannot create an offer lower than an existing one.")
        property_rec.state = 'offer_received'
        return super().create(vals)


