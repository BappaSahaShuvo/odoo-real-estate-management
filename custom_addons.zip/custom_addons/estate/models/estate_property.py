from odoo import fields, models, api
from datetime import timedelta
from odoo.exceptions import UserError, ValidationError
from dateutil.relativedelta import relativedelta
from odoo.tools.float_utils import float_compare, float_is_zero



class EstateProperty(models.Model):
    _name = 'estate.property'
    _description = 'Real Estate Property'
    _order = 'id desc'

    _sql_constraints = [
        (
            'check_expected_price_positive',
            'check(expected_price  > 0)',
            'Expected price must be strictly positive.'
        ),
        (
            'check_selling_price_positive',
            'check(selling_price  >= 0)',
            'Selling price must be positive.'
        ),
    ]


    name = fields.Char(string='Property Name', required=True,store=True)
    description = fields.Text()
    postcode = fields.Char(store=True)
    date_availability = fields.Date(
        copy=False,
        default=lambda self: fields.Date.today() + relativedelta(months=3)
    )
    expected_price = fields.Float(required=True)
    selling_price = fields.Float(
        readonly=True,
        copy=False
    )
    bedrooms = fields.Integer(default=2, store=True)
    living_area = fields.Integer()
    facades = fields.Integer()
    garage =  fields.Boolean()
    garden = fields.Boolean()
    garden_area = fields.Integer()
    garden_orientation = fields.Selection([
        ('north', 'North'),
        ('south', 'South'),
        ('east', 'East'),
        ('west', 'West'),
    ])
    active = fields.Boolean(default=True)

    state = fields.Selection([
        ('new', 'New'),
        ('offer_recived', 'Offer Recived'),
        ('offer_accepted', 'Offer Accepted'),
        ('sold', 'Sold'),
        ('cancelled', 'Cancelled'),
    ], default='new'
    )
    property_type_id = fields.Many2one(
        "estate.property.type",
        string="Property Type"
    )
    buyer_id = fields.Many2one(
        "res.partner",
        string="Buyer",
        copy=False
    )
    salesperson_id = fields.Many2one(
        "res.users",
        string="Salesperson",
        default=lambda self: self.env.user
    )
    tag_ids = fields.Many2many(
        "estate.property.tag",
        string="Tags",
    )
    offer_ids = fields.Many2many(
        "estate.property.offer",
        "property_id"
    )
    sequence = fields.Integer(default=1)
    total_area = fields.Float(
        compute="_compute_total_area",
    )

    @api.depends("living_area", "garden_area")
    def _compute_total_area(self):
        for record in self:
            record.total_area = record.living_area + record.garden_area

    best_price = fields.Float(
        compute="_compute_best_price",
    )
    @api.depends("offer_ids.price")
    def _compute_best_price(self):
        for record in self:
            if record.offer_ids:
                record.best_price = max(record.offer_ids.mapped('price'))
            else:
                record.best_price = 0.0

    validity = fields.Integer(defult=7)
    date_deadline = fields.Date(
        compute="_compute_date_deadline",
        inverse="_inverse_date_deadline",
    )
    @api.depends("validity", "create_date")
    def _compute_date_deadline(self):
        for record in self:
            create_date = record.create_date or fields.Datetime.now()
            record.date_deadline = (
                create_date.date() + timedelta(days=record.validity)
            )
    def _inverse_date_deadline(self):
        for record in self:
            if record.create_date and record.date_deadline:
                delta = record.date_deadline - record.create_date.date()
                record.validity = delta.days

    @api.onchange("garden")
    def _onchange_garden(self):
        if self.garden:
            self.garden_area = 10
            self.garden_orientation = 'north'
        else:
            self.garden_area = 0
            self.garden_orientation = False

    def action_sold(self):
        for record in self:
            if record.state == "cancelled":
                raise UserError("Cancelled property cannot be sold.")
            record.state = "sold"
        return True

    def action_cancelled(self):
        for record in self:
            if record.state == "sold":
                raise UserError("Sold property cannot be cancelled.")
            record.state = "cancelled"
        return True

    @api.constrains('selling_price', 'expected_price')
    def _check_selling_price(self):
        for record in self:
            if record.selling_price and record.expected_price:
                min_price = record.expected_price * 0.9
                if float_compare(
                        record.selling_price,
                        min_price,
                        precision_rounding=0.01
                ) < 0:
                    raise ValidationError(
                        "Selling price cannot be lower than 90% of the expected price."
                    )
    @api.ondelete(at_uninstall=False)
    def _check_property_deletion(self):
        for record in self:
            if record.state not in ('new', 'cancelled'):
                raise ValidationError("You can only delete properties in New or Cancelled state.")




    required=True,
    copy=False,
    store=True,
    default='new'