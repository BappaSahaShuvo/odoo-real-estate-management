from odoo import fields, models, Command

class EstateProperty(models.model):
    _inherit = "estate.property"

    def action_sold(self):

        res = super().action_sold()

        self.env["account.move"].create({
            "partner_id": self.buyer_id.id,
            "move_type": "out_invoice",
            "invoice_line_ids": [
                Command.create({
                    "name": "6% Property Commission",
                    "quantity": 1,
                    "price_unit": self.selling_price * 0.06,
                }),
                Command.create({
                    "name": "Administrative Fees",
                    "quantity": 1,
                    "price_unit": 100.0,
                }),
            ],
        })
        return res