{
    'name' : 'Estate Account',
    'version': '1.0',
    'depends': [
        'estate',
        'account'
         ],
    'data' : [],
    'installable': True,
}